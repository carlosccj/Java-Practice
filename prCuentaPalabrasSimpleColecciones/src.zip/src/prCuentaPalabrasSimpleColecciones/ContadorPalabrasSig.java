package prCuentaPalabrasSimpleColecciones;

import java.io.*;
import java.util.*;

public class ContadorPalabrasSig extends ContadorPalabras {
	private Set<String> noSignificativas;

	public ContadorPalabrasSig(Collection<String> palNS) {
		super();
		palNS = normalizar(palNS);
		noSignificativas = new HashSet<String>();
	}

	public ContadorPalabrasSig(String filNoSig, String del) throws FileNotFoundException {
		super();
		noSignificativas = new HashSet<String>();
		leerFicheroNoSig(filNoSig, del);
	}

	private void leerFicheroNoSig(String filNoSig, String del) throws FileNotFoundException {
		try (Scanner sc = new Scanner(new File(filNoSig))) {
			leerPalabrasNoSignificativas(sc, del);
		}
	}

	private void leerPalabrasNoSignificativas(Scanner sc, String del) {
		while (sc.hasNextLine()) {
			try (Scanner sc2 = new Scanner(sc.nextLine())) {
				sc2.useDelimiter(del);
				while (sc2.hasNext()) {
					String y = sc2.next().toUpperCase();
					noSignificativas.add(y);
				}
			}
		}
	}

	private Collection<String> normalizar(Collection<String> x) {
		SortedSet<String> r = new TreeSet<String>();
		for (String p : x) {
			r.add(p.toUpperCase());
		}
		return r;
	}

	@Override
	protected void incluye(String pal) {
		if (!(noSignificativas.contains(pal))) {
			super.incluye(pal);
		}
	}
}
