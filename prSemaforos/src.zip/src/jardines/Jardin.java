package jardines;

public class Jardin {
	
	private int visitantes;
	
	public Jardin() {
		visitantes = 0;
	}

	public int  getVisitantes() {
		return visitantes;
	}
	
	public void nuevoVisitante(int idP) {
		//pre-protocolo
		//TODO
		
		//SC
		System.out.println("Nuevo visitante por puerta "+idP);
		visitantes++;
		System.out.println("Total visitantes "+visitantes);
		
		//pos-protocolo
		//TODO
	}
	public static void main(String[] args) {
		Jardin jardin = new Jardin();
		Puerta p1 = new Puerta(1,jardin);
		Puerta p2 = new Puerta(2,jardin);
		
		p1.start();
		p2.start();
		
		try {
			p1.join();
			p2.join();
			System.out.println("Total visitantes: "+jardin.getVisitantes());
		}catch(InterruptedException e) {
			e.printStackTrace();
		}

	}

}
