package prCuentaPalabrasSimpleColecciones;

import java.util.*;
import java.io.*;

public class ContadorPalabras {
	private SortedSet<PalabraEnTexto> palabras;

	public ContadorPalabras() {
		palabras = new TreeSet<PalabraEnTexto>();
	}

	protected void incluye(String pal) {
		if (pal != "") {
			PalabraEnTexto x = new PalabraEnTexto(pal);
			if (palabras.contains(x)) {
				Iterator<PalabraEnTexto> it = palabras.iterator();
				while (it.hasNext()) {
					if (x.equals(it.next())) {
						it.next().incrementa();
					}
				}
			} else {
				palabras.add(x);
			}
		}
	}
	
	private PalabraEnTexto buscar(PalabraEnTexto x) {
		Iterator<PalabraEnTexto> it = palabras.iterator();
		PalabraEnTexto res = null;
		boolean ok = false;
		while (it.hasNext() && !ok) {
			if (x.equals(it.next())) {
				res = it.next();
			}
		}
		return res;
	}

	/*
	private static <E> PalabraEnTexto buscar(SortedSet<PalabraEnTexto> c, PalabraEnTexto e) {
		PalabraEnTexto a = null;
		Iterator<PalabraEnTexto> it = c.iterator();
		while ((a == null) && it.hasNext()) {
			PalabraEnTexto x = it.next();
			if (x.equals(e)) {
				a = x;
			}
		}
		return a;
	}
	*/

	private void incluyeTodas(String linea, String del) {
		String[] pals = linea.split(del);
		for (int i = 0; i < pals.length; i++) {
			incluye(pals[i]);
		}
	}

	public void incluyeTodas(String[] texto, String del) {
		for (int i = 0; i < texto.length; i++) {
			incluyeTodas(texto[i], del);
		}
	}

	public void incluyeTodasFichero(String nomFich, String del) {
		try (Scanner sc = new Scanner(new File(nomFich))) {
			leerFichero(sc, del);
		} catch (FileNotFoundException e) {
			System.out.println("El archivo no fue encontrado");
		}
	}

	private void leerFichero(Scanner sc, String del) {
		while (sc.hasNextLine()) {
			try (Scanner sc2 = new Scanner(sc.nextLine())) {
				sc2.useDelimiter(del);
				while (sc2.hasNext()) {
					incluye(sc2.next());
				}
			}
		}
	}

	public PalabraEnTexto encuentra(String pal) {
		PalabraEnTexto x = new PalabraEnTexto(pal);
		if (palabras.contains(x)) {
			x = buscar(x);
		} else {
			throw new NoSuchElementException();
		}
		return x;
	}

	public void presentaPalabras(String fichero) throws FileNotFoundException {
		try (PrintWriter pw = new PrintWriter(new File(fichero))) {
			presentaPalabras(pw);
		}
	}

	public void presentaPalabras(PrintWriter pw) {
		Iterator<PalabraEnTexto> it = palabras.iterator();
		while (it.hasNext()) {
			pw.println(it.next());
		}
	}

	@Override
	public String toString() {
		Iterator<PalabraEnTexto> it = palabras.iterator();
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		if (!palabras.isEmpty()) {
			while (it.hasNext()) {
				sb.append(it.next().toString() + ", ");
			}
		}
		sb.append("]");
		return sb.toString();
	}

}
