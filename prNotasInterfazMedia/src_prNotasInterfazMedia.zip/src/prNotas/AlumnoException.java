package prNotas;


public class AlumnoException extends Exception {
	public AlumnoException() {
		super();
	}
	
	public AlumnoException(String msg) {
		super(msg);
	}

}
