package prNotas;

public interface CalculoMedia {
	public abstract double calcular(Alumno[] alumnos) throws AlumnoException;
	}
