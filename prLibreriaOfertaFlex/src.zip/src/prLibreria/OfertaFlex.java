package prLibreria;

public interface OfertaFlex {
	public abstract double getDescuento (Libro x);
}